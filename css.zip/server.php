 <?php
// Вывод заголовка с данными о кодировке страницы
header('Content-Type: text/html; charset=utf-8');
session_start(); 
// инициализируем переменные

// связь с базой данных
/*$db = mysqli_connect('localhost', 'a0581703_111', '111', 'a0581703_111')or die('Connection error.');
mysqli_query($db, "SET NAMES 'utf8'");*/
// REGISTER USER
if (isset($_POST['start'])) {

  	$_SESSION['num'] = 1;
  	header('location: index.html');
	exit();
  }
}
//UPDATE USER
if (isset($_POST['upd_user'])) {
    $name = mysqli_real_escape_string($db, $_POST['name']);
    $surname = mysqli_real_escape_string($db, $_POST['surname']);
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
    $number = mysqli_real_escape_string($db, $_POST['number']);
    //$email = $_SESSION['email'];
    
    $execItems = $db->query("SELECT id FROM `users` WHERE email='$email'");
    while($infoItems = $execItems->fetch_array()){
	    $id = $infoItems['id'];
    }
    
    
   
  
      
      	$password = md5($password);
    
      	$query = "UPDATE users SET name = '$name' ,surname = '$surname', email = '$email', phone_number = '$number', password = '$password' WHERE id='$id'";
      	mysqli_query($db, $query)or die("Ошибка " . mysqli_error($db));
      	header('location: settings.html');
    	exit();
      
    
}

	// LOGIN USER
	if (isset($_POST['log_user'])) {
	$pass = "";
	$email = mysqli_real_escape_string($db, $_POST['email']);
	$password = mysqli_real_escape_string($db, $_POST['password']);
	
  if (empty($email)) {array_push($errors, "E-mail is required");}
  if (empty($password)) {array_push($errors, "Password is required");}

  if (count($errors) == 0) {
  	$pass = md5($password);
  	$query = "SELECT * FROM users WHERE email='$email' AND password='$pass'";
  	$results = mysqli_query($db, $query);
  	if (mysqli_num_rows($results) == 1) {
  	  $_SESSION['email'] = $email;
  	  setcookie('name', '$email');
  	  
  	  $_SESSION['msg'] = "You are now logged in";
  	  if ($_SESSION['email'] == "admin@mail.ru"){
  	      header('location: admin-accounts.html');
  	  }
  	  else header('location: account.html');
	  exit();
  	}
	else array_push($errors, "Wrong number/password combination");
  } 
}
//EXIT
if (isset($_POST['exit'])) {
    session_destroy();
    header('location: login.html');
	exit();
}
//